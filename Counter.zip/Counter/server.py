from flask import Flask, render_template, request, redirect, session
app = Flask(__name__)
app.secret_key = "booobs"

@app.route("/")
def index():
    if "user" not in session:
        session["user"] = 0
    session["user"] += 1
    return render_template("index.html", num=session["user"])

@app.route("/two")
def two():
    session["user"]=session["user"]+1
    return redirect("/")

@app.route("/usersChoice", methods=["POST"])
def usersChoice():
    name = request.form["number"]
    session["user"] += int(name) - 1
    return redirect("/")

@app.route("/destroy_session")
def destroy():
    session.clear()
    return redirect("/")

if __name__ == "__main__":
    app.run(debug=True)